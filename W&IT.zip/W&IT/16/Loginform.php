<html>
<head>
<title> Registration page </title>
</head>
<body bgcolor="pink">

<?php
$myxml=simplexml_load_file("Userlogin.xml");
$username=$_POST['uname'];
$password=$_POST['upwd'];
$xmlusername="";
$xmlpassword="";

for($i=0;$i<count($myxml);$i++)
{
$xmlusername=$myxml->user[$i]->username;
$xmlpassword=$myxml->user[$i]->password;

if($xmlusername==$username && $xmlpassword==$password)

{
echo "welcome $username";
die();
}

}
echo "Invalid username or password";
?>

</body>
</html>
